#!/bin/bash
# Reasoner commands
# the reported time was an average of results obtained in 5 iterations and that was performed manually.


#ontologies must be in OWL/Functional syntax for both ELK and Konclude. Either convert them by changing the configuration file of OWL2Bench or simply use Convert.java (that is present in the directory).

#download konclude from https://www.derivo.de/fileadmin/externe_websites/ext.derivo/KoncludeReleases/v0.6.2-544/Konclude-v0.6.2-544-Linux-x64-GCC4.3.2-Static-Qt4.8.5.zip

#RAM should be 24GB (although konclude is much faster, it uses too much of memory and thus could not perform msot of the experiments)
file_path=$(pwd)
#change to konclude directory
echo $file_path

owl_files=$(ls *.owl)

total=0
for i in $owl_files
do
	echo $i
	java -jar convert.jar ofn $i

	arr=(-1 -1 -1 -1 -1 -1)
	k=0
	for task in consistency realisation classification
	do
		echo $task
		start=$SECONDS
		#mem=5
		s=`mktemp`
		echo "start : $start"
		/usr/bin/time -f "%E"  timeout 21600 ./Konclude $task -i $i
		#z=$(/usr/bin/time -f "%M" -o "$s" timeout 21600 ./Konclude $task -i $i | tail -n 1 | cut -d' ' -f 7)
		#z=$(/usr/bin/time -f "%M" -o "$s" timeout 21600 ./Konclude consistency -i 00a47ea4-c236-4894-b8fb-a15d3d66c110_onto.rdf_functional.owl | tail -n 1 | cut -d' ' -f 7)
		#mem=$(cat "$s")
		#p=$(cat "$y")
		#z=./Konclude $task -i $i
		#echo "Memory consumed: $mem"
	      	#echo "time = $p"
	      	#z=$(./Konclude consistency -i 00a47ea4-c236-4894-b8fb-a15d3d66c110_onto.rdf_functional.owl | tail -n 1 | cut -d' ' -f 7)
		#echo $z
		ELAPSED_TIME=$(($SECONDS - $start))
		
		echo "Script Execution Time : $ELAPSED_TIME"

		arr[$k]=$ELAPSED_TIME
		k=`expr $k + 1`
		arr[$k]=$mem
		k=`expr $k + 1`
		SECONDS=0
	done
	#printf '%s\n' ${arr[0]} ${arr[1]} ${arr[2]} ${arr[3]} ${arr[4]} ${arr[5]} | paste -sd ',' >> file.csv
	break
done


